function Education() {
  const education = [
    {
      degree: "Master of Science (M.Sc.)",
      field: "Computer Applications",
      institution: "Maharaja Ganga Singh University (MGSU)",
      year: "2023 - 2025",
      description: "Focus on computer applications providing a strong technical background to complement design skills."
    },
    {
      degree: "Bachelor of Science (B.Sc.)",
      field: "Physics, Mathematics, CS",
      institution: "Maharaja Ganga Singh University (MGSU)",
      year: "2020 - 2023",
      description: "Comprehensive study of core sciences with a specialization in Computer Science (PM+CS)."
    }
  ];

  const certifications = [
    {
      name: "Graphic Design Certificate",
      issuer: "Professional Design Certification",
      year: "2024",
      icon: "icon-palette"
    },
    {
      name: "Digital Marketing Certificate",
      issuer: "Professional Certification",
      year: "2024",
      icon: "icon-trending-up"
    },
    {
      name: "RSCIT Certificate",
      issuer: "Vardhman Mahaveer Open University",
      year: "2023",
      icon: "icon-monitor"
    }
  ];

  return (
    <section className="section-padding bg-[var(--card-bg)]" data-name="education" data-file="components/Education.js">
      <div className="container mx-auto">
        <h2 className="section-title mb-12">Education & Certifications</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Education Column */}
          <div className="print:break-inside-avoid">
            <h3 className="text-2xl font-bold text-white mb-8 flex items-center print:text-black">
              <div className="icon-graduation-cap text-[var(--primary-yellow)] mr-3 print:text-black"></div>
              Academic Background
            </h3>
            <div className="space-y-8">
              {education.map((edu, index) => (
                <div key={index} className="border-l-2 border-[var(--primary-yellow)] pl-6 relative print-break-avoid print:border-black">
                  <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-[var(--primary-yellow)] print:bg-black"></div>
                  <h4 className="text-xl font-bold text-white print:text-black">{edu.degree}</h4>
                  <p className="text-[var(--primary-yellow)] font-bold text-sm uppercase tracking-wider mb-1 print:text-black">{edu.field}</p>
                  <div className="flex justify-between items-center text-gray-400 text-sm mb-3 print:text-gray-600">
                    <span>{edu.institution}</span>
                    <span>{edu.year}</span>
                  </div>
                  <p className="text-[var(--text-muted)] print:text-gray-700">{edu.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications Column */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-8 flex items-center">
              <div className="icon-award text-[var(--primary-yellow)] mr-3"></div>
              Certifications
            </h3>
            <div className="grid gap-6">
              {certifications.map((cert, index) => (
                <div key={index} className="bg-[#121212] p-6 border border-white/5 flex items-center group hover:border-[var(--primary-yellow)] transition-all duration-300">
                  <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mr-4 group-hover:bg-[var(--primary-yellow)] transition-colors">
                    <div className={`${cert.icon} text-xl text-[var(--primary-yellow)] group-hover:text-black`}></div>
                  </div>
                  <div>
                    <h4 className="font-bold text-white group-hover:text-[var(--primary-yellow)] transition-colors">{cert.name}</h4>
                    <p className="text-sm text-gray-400">{cert.issuer} • {cert.year}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}