# Graphic Designer Portfolio Project

## Overview
This project is a high-end, dark-themed portfolio website designed for a multidisciplinary graphic designer. It showcases a broad skillset including Photoshop, Illustrator, Figma, CorelDRAW, and InDesign, covering everything from manipulation to UI/UX and print design.

## Structure
- `index.html`: Main entry with Tailwind configuration and font loading.
- `app.js`: Root React component.
- `components/`: UI components for Hero, About, Skills, Portfolio, etc.
- `layouts/`: Shared layout wrappers.

## Maintenance
- Ensure Tailwind configuration in `index.html` is updated if color schemes change.
- Update `trickle/assets` when replacing placeholder images.