When updating the project structure or adding significant features:
- Check if the `trickle/notes/README.md` needs to be updated to reflect the changes.
- Ensure the overview and structure sections remain accurate.